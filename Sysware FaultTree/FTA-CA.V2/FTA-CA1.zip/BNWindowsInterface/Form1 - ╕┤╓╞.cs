﻿using FT2Cutset;
using FT2GenieBN;
using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace BNWindowsInterface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /*NEntrance go;*/
        private void button1_Click(object sender, EventArgs e)
        {

            textBox3.Text = (new CutsetEntrance()).GO(textBox4.Text);
            return;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            FTBNEntrance go = new FTBNEntrance(textBox4.Text, true);
            //return;

            //FTBNEntrance go = new FTBNEntrance(textBox2.Text);
            //go.GOCalculateProbability(int.Parse(textBox1.Text));
            go.GOCalculateProbability();
            textBox3.Text = "概率计算耗时：" + sw.ElapsedMilliseconds + "ms";

            textBox3.Text += Environment.NewLine;
            textBox3.Text += go.GetPrbsResultXML();
            sw.Stop();

            textBox3.Text += Environment.NewLine;
            textBox3.Text += Environment.NewLine;

            sw.Start();
            go.GOCalculateImportance();
            sw.Stop();
            textBox3.Text += Environment.NewLine + "重要度计算耗时：" + sw.ElapsedMilliseconds + "ms";

            textBox3.Text += Environment.NewLine;
            textBox3.Text += go.GetIMPsResultXML();
        }


        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Stopwatch sw = new Stopwatch();
            //sw.Start();

            //FT2GenieBNs.FTBNEntrance go = new FT2GenieBNs.FTBNEntrance(textBox2.Text);
            //go.GOCalculateProbability();

            //sw.Stop();
            //textBox3.Text = go.GetResultText() + Environment.NewLine + "耗时" + sw.ElapsedMilliseconds + "ms";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Stopwatch sw = new Stopwatch();
            //sw.Start();

            //FT2GenieBN.FTBNEntrance go = new FT2GenieBN.FTBNEntrance(textBox2.Text);
            ////go.GOCalculateProbability(int.Parse(textBox1.Text));
            //go.GOCalculateProbability();
            //textBox3.Text = "概率计算耗时：" + sw.ElapsedMilliseconds + "ms";

            //textBox3.Text += Environment.NewLine;
            //textBox3.Text += go.GetPrbsResultXML();
            //sw.Stop();

            //textBox3.Text += Environment.NewLine;
            //textBox3.Text += Environment.NewLine;

            //sw.Start();
            //go.GOCalculateImportance();
            //sw.Stop();
            //textBox3.Text += Environment.NewLine + "重要度计算耗时：" + sw.ElapsedMilliseconds + "ms";

            //textBox3.Text += Environment.NewLine;
            //textBox3.Text += go.GetIMPsResultXML();
        }
    }
}
