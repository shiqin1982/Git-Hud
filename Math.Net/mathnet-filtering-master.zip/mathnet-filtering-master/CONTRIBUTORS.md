Math.NET Filtering Contributors
===============================

The Math.NET project is a community effort. We accept contributions and pull requests, but other support like submitting issues or helping the community are just as valuable. Why don't you join us as well?

**Thanks for all the contributions!**

### Maintainers

- [Christoph Rüegg](http://christoph.ruegg.name/) (@cdrnet) ([keybase.io/cdrnet](https://keybase.io/cdrnet))

### Code Contributors

*Essentially the output of `git shortlog -sn` in original order.  
Feel free to add a link to your personal site/blog and/or twitter handle.*

- [Christoph Rüegg](http://christoph.ruegg.name/) (@cdrnet)
- Matthew Kitchin
- Thomas Ibel
- Albert-Jan Nijburg
