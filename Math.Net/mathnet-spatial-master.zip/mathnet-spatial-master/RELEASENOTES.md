### 0.4.0 - 2017-05-01
* Build: extra *.Signed packages with strong named assemblies for legacy use cases
* Polygon: order points on the convex hull clockwise *~Per Kuijpers*

### 0.3.0 - 2016-11-05
* Various additions and fixes

### 0.2.0-alpha - 2015-04-20
* Coordinate System: Rotation overloads
* Coordinate System: OffsetBy
* Homogeneous Coordinates *~luisllamasbinaburo*
* Split into Euclidean and Projective namespaces
* BUG: fix Vector3D.ProjectOn *~Ralle*
* Angle: various improvements and fixes
* Compatibility: downgraded to .Net 4.0 (from .Net 4.5)

### 0.1.1-alpha - 2014-10-08
* Initial version
