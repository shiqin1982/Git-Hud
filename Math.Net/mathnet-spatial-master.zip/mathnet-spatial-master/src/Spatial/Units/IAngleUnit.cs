namespace MathNet.Spatial.Units
{
    public interface IAngleUnit : IUnit
    {
    }
}