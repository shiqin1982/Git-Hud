Data IO for Math.NET Numerics
=============================

Extension libraries to help you load external data into Math.NET Numerics and then store it back.
