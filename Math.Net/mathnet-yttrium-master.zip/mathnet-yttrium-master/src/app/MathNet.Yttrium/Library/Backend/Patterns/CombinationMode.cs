using System;
using System.Collections.Generic;
using System.Text;

namespace MathNet.Symbolics.Backend.Patterns
{
    public enum CombinationMode
    {
        None,
        All,
        One,
        AtLeastOne,
        AtMostOne
    }
}
