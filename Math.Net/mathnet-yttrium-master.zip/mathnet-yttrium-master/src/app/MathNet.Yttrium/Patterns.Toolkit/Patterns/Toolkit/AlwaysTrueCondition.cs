#region Math.NET Yttrium (GPL) by Christoph Ruegg
// Math.NET Yttrium, part of the Math.NET Project
// https://yttrium.mathdotnet.com
//
// Copyright (c) 2001-2007, Christoph R�egg,  http://christoph.ruegg.name
//						
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace MathNet.Symbolics.Patterns.Toolkit
{
    public class AlwaysTrueCondition : Condition
    {
        private static AlwaysTrueCondition _instance;

        private AlwaysTrueCondition() {}

        public static AlwaysTrueCondition Instance
        {
            get
            {
                if(_instance == null)
                    _instance = new AlwaysTrueCondition();
                return _instance;
            }
        }

        public override int Score
        {
            get { return 0; }
        }

        public override bool FulfillsCondition(Signal output, Port port)
        {
            return true;
        }

        public override bool Equals(Condition other)
        {
            return other is AlwaysTrueCondition;
        }

        protected override void MergeToCoalescedTreeNode(CoalescedTreeNode parent, List<CoalescedTreeNode> children)
        {
            children.Add(parent);
        }

        protected override bool CouldMergeToCoalescedTreeNode(Condition condition)
        {
            return true;
        }
    }
}
