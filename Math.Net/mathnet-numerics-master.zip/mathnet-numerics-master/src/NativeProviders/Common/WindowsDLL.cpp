#ifndef VC_EXTRALEAN
	#define VC_EXTRALEAN
#endif
#include "windows.h"

BOOL APIENTRY DllMain( HANDLE, DWORD, LPVOID ){
	return TRUE;
}
