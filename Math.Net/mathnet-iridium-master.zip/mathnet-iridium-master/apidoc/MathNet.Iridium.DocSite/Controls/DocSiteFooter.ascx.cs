using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Reflection;

namespace MathNet.Iridium.DocSite.Controls
{
    public partial class DocSiteFooter : System.Web.UI.UserControl
    {
        #region Public Properties
        #endregion

        #region Private / Protected
        #endregion

        #region Constructors
        /// <summary>
        /// Constructs a new instance of the <see cref="DocSiteFooter" /> class.
        /// </summary>
        public DocSiteFooter()
        {
        }
        #endregion

        #region Methods
        #endregion

        #region Events
        #endregion

        #region Event Handlers
        #endregion
    }
}